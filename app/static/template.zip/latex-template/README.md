# latex-template
## Description
Template for LaTeX and compile script.

## Usage
```
$ ./compile
```

Compile tex file that written as "documentclass".

"build" directory is created and generate PDF under "build" directory.

```
$ ./compile clean
```

This command delete "build" directory.

## Author
shidaru
